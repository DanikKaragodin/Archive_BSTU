﻿using System;
using System.Windows.Forms;

namespace BD5
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void услугиBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.услугиBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.услугиDataSet);

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "услугиDataSet.Услуги". При необходимости она может быть перемещена или удалена.
            this.услугиTableAdapter.Fill(this.услугиDataSet.Услуги);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            услугиBindingSource.MoveFirst();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            услугиBindingSource.MoveLast();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            услугиBindingSource.MovePrevious();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            услугиBindingSource.MoveNext();
        }
        private void button5_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.услугиBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.услугиDataSet);
        }
        private void button6_Click(object sender, EventArgs e)
        {
            услугиBindingSource.AddNew();
        }
        private void button7_Click(object sender, EventArgs e)
        {
            услугиBindingSource.RemoveCurrent();
        }


    }
}
