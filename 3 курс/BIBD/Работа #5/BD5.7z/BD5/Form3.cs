﻿using System;
using System.Windows.Forms;

namespace BD5
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void фирмыBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.фирмыBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.услугиDataSet);

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "услугиDataSet.Заказы". При необходимости она может быть перемещена или удалена.
            // this.заказыTableAdapter.Fill(this.услугиDataSet.Заказы);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "фирмыDataSet.Фирмы". При необходимости она может быть перемещена или удалена.
            this.фирмыTableAdapter.Fill(this.услугиDataSet.Фирмы);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            фирмыBindingSource.MoveFirst();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            фирмыBindingSource.MoveLast();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            фирмыBindingSource.MovePrevious();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            фирмыBindingSource.MoveNext();
        }
        private void button5_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.фирмыBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.услугиDataSet);
        }
        private void button6_Click(object sender, EventArgs e)
        {
            фирмыBindingSource.AddNew();
        }
        private void button7_Click(object sender, EventArgs e)
        {
            фирмыBindingSource.RemoveCurrent();
        }
    }
}
