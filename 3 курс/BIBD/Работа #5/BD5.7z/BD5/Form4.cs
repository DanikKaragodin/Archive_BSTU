﻿using System;
using System.Windows.Forms;

namespace BD5
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void заказыBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.заказыBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.услугиDataSet);

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "услугиDataSet.Заказы". При необходимости она может быть перемещена или удалена.
            this.заказыTableAdapter.Fill(this.услугиDataSet.Заказы);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            заказыBindingSource.MoveFirst();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            заказыBindingSource.MoveLast();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            заказыBindingSource.MovePrevious();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            заказыBindingSource.MoveNext();
        }
        private void button5_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.заказыBindingSource.EndEdit();
            //this.заказыTableAdapter.Update(this.услугиDataSet.Заказы);
            //this.заказыTableAdapter.Fill(this.услугиDataSet.Заказы);
            this.tableAdapterManager.UpdateAll(this.услугиDataSet);
        }
        private void button6_Click(object sender, EventArgs e)
        {
            if (заказыBindingSource != null)
                заказыBindingSource.AddNew();
        }
        private void button7_Click(object sender, EventArgs e)
        {
            if (заказыBindingSource != null)
                заказыBindingSource.RemoveCurrent();
        }

        private void заказыBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.заказыBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.услугиDataSet);

        }
    }
}
